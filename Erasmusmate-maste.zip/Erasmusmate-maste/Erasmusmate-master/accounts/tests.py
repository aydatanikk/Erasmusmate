# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.test import TestCase
from accounts.models import Profile, UserProfile
from django.contrib.auth.models import User

from django.core.urlresolvers import reverse
from django.utils import timezone

# Create your tests here.
